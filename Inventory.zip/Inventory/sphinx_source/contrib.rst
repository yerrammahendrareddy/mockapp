.. :tocdepth:: 2

Contributing to Shopyo
======================

If would like to contribute to Shopyo feel free todo so
learners are also welcome and and we wil try and help when we can.

There a various ways to contribute to shopyo

* fixing or applying new features
* bug hunting
* documentation

💬 Community: Discord
---------------------
 Join the Discord community `Discord Group <https://discord.gg/k37Ef6w/>`_

.. toctree::

        Building a template <templates>
        Creating a model <models>
        Creating a view <views>
        Creating unittests <unittests>
